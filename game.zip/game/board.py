"""
board.py — Core Board Representation for SameGame

Responsibilities:
- Represent the 8×8 game board as a 2D list
- Provide serialization for DP memoization
- Support board copying for simulation
"""

import random
import copy

ROWS = 8
COLS = 8
NUM_COLORS = 3  # Colors represented as 0, 1, 2


def create_board(seed=None):
    """
    Create a new random 8×8 board.
    Each cell is a random integer in [0, NUM_COLORS-1].
    seed allows reproducibility.
    """
    if seed is not None:
        random.seed(seed)
    return [[random.randint(0, NUM_COLORS - 1) for _ in range(COLS)] for _ in range(ROWS)]


def copy_board(board):
    """Return a deep copy of the board."""
    return copy.deepcopy(board)


def serialize_board(board):
    """
    Convert board to a hashable tuple-of-tuples for memoization.
    
    Why: DP memo tables require hashable keys.
    Determinism: row-major order guarantees consistent serialization.
    """
    return tuple(tuple(row) for row in board)


def deserialize_board(serialized):
    """Convert serialized tuple back to a 2D list."""
    return [list(row) for row in serialized]


def board_is_empty(board):
    """Check if all cells are -1 (empty/removed)."""
    return all(board[r][c] == -1 for r in range(ROWS) for c in range(COLS))


def count_remaining(board):
    """Count non-empty cells remaining on the board."""
    return sum(1 for r in range(ROWS) for c in range(COLS) if board[r][c] != -1)


def score_for_region(region_size):
    """
    SameGame scoring formula: (size - 2)^2
    A region of size < 2 is invalid and scores 0.
    """
    if region_size < 2:
        return 0
    return (region_size - 2) ** 2


def board_to_list(board):
    """Convert board to plain list-of-lists (for JSON serialization)."""
    return [list(row) for row in board]
