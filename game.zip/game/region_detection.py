"""
region_detection.py — Connected Region Detection for SameGame

This module finds all connected groups of same-colored cells using BFS/DFS.
A "region" is a set of (row, col) positions with the same color and mutual adjacency.

Used by both solvers to enumerate valid moves.
"""

from collections import deque
from game.board import ROWS, COLS


def find_region(board, start_r, start_c):
    """
    BFS from (start_r, start_c) to find all connected cells of the same color.
    
    Returns: list of (r, c) tuples in the connected region.
    Returns empty list if the starting cell is empty (-1).
    """
    color = board[start_r][start_c]
    if color == -1:
        return []

    visited = set()
    queue = deque()
    queue.append((start_r, start_c))
    visited.add((start_r, start_c))

    while queue:
        r, c = queue.popleft()
        for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            nr, nc = r + dr, c + dc
            if (0 <= nr < ROWS and 0 <= nc < COLS
                    and (nr, nc) not in visited
                    and board[nr][nc] == color):
                visited.add((nr, nc))
                queue.append((nr, nc))

    return list(visited)


def find_all_regions(board):
    """
    Enumerate ALL distinct connected regions on the board.
    
    Strategy:
    - Scan every cell in row-major order
    - If a cell hasn't been assigned to a region, run BFS from it
    - Only include regions with size >= 2 (valid moves)
    
    Returns: list of regions, each region is a list of (r, c) tuples.
    
    Why this matters for DP:
    - Each region = one possible move
    - The set of regions defines the branching factor of the DP recurrence
    """
    visited_cells = set()
    regions = []

    for r in range(ROWS):
        for c in range(COLS):
            if board[r][c] == -1 or (r, c) in visited_cells:
                continue

            region = find_region(board, r, c)
            for cell in region:
                visited_cells.add(cell)

            if len(region) >= 2:
                regions.append(region)

    return regions


def region_representative(region):
    """
    Return the top-left cell of a region as its canonical representative.
    Useful for deterministic ordering.
    """
    return min(region, key=lambda rc: (rc[0], rc[1]))
