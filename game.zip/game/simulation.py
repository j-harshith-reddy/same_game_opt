"""
simulation.py — Board Simulation Logic for SameGame

This module handles:
1. Region removal (mark cells as -1)
2. Gravity (cells fall downward into empty spaces)
3. Column shifting (empty columns collapse left)

These three steps together define the STATE DP version of SameGame.

The SUBSET DP version uses only step 1 (region removal), with no gravity or shifting.
"""

from game.board import copy_board, ROWS, COLS


def remove_region(board, region):
    """
    Remove all cells in the region by setting them to -1.
    
    Validation: only regions with size >= 2 should be passed here.
    Returns a new board (does not mutate input).
    """
    if len(region) < 2:
        raise ValueError("Cannot remove a region of size < 2.")

    new_board = copy_board(board)
    for (r, c) in region:
        new_board[r][c] = -1
    return new_board


def apply_gravity(board):
    """
    Apply gravity: cells fall downward within each column.
    
    For each column:
    - Collect all non-empty values from top to bottom
    - Fill from the bottom upward with those values
    - Fill remaining top cells with -1
    
    Returns a new board.
    
    Example:
      Before:   After:
      [1]       [-1]
      [-1]  →   [-1]
      [2]       [1]
      [-1]      [2]
    """
    new_board = copy_board(board)
    for c in range(COLS):
        # Collect non-empty values in top-to-bottom order
        column_values = [new_board[r][c] for r in range(ROWS) if new_board[r][c] != -1]
        # Number of empty cells = total rows - non-empty
        empty_count = ROWS - len(column_values)
        # Fill: top cells are -1, bottom cells are the values
        for r in range(ROWS):
            if r < empty_count:
                new_board[r][c] = -1
            else:
                new_board[r][c] = column_values[r - empty_count]
    return new_board


def apply_column_shift(board):
    """
    Apply column shift: remove entirely empty columns and shift remaining columns left.
    
    A column is empty if all ROWS cells are -1.
    Non-empty columns are compacted to the left side of the board.
    Positions on the right of the last non-empty column become all -1.
    
    Returns a new board.
    
    Example (4×4 board for illustration):
      Before:           After:
      [-1, 1, -1, 2]    [1, 2, -1, -1]
      [-1, 3, -1, 4]    [3, 4, -1, -1]
    """
    new_board = [[- 1] * COLS for _ in range(ROWS)]

    non_empty_cols = []
    for c in range(COLS):
        if any(board[r][c] != -1 for r in range(ROWS)):
            non_empty_cols.append(c)

    for new_c, old_c in enumerate(non_empty_cols):
        for r in range(ROWS):
            new_board[r][new_c] = board[r][old_c]

    return new_board


def simulate_move(board, region):
    """
    Full simulation of a State DP move:
    1. Remove region
    2. Apply gravity
    3. Apply column shift
    
    Returns the resulting board after all three steps.
    This function is the core transition function for STATE DP.
    """
    board_after_removal = remove_region(board, region)
    board_after_gravity = apply_gravity(board_after_removal)
    board_after_shift = apply_column_shift(board_after_gravity)
    return board_after_shift


def simulate_move_no_gravity(board, region):
    """
    Simulation for Subset DP: remove region only.
    No gravity, no column shift.
    Cells stay in their original positions; removed cells become -1.
    
    This matches the Subset DP rule set where regions are STATIC
    because positions never change.
    """
    return remove_region(board, region)
