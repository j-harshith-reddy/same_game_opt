import random
from flask import Flask, request, jsonify, send_from_directory

from ai import cpu_choose_move

app = Flask(__name__)

# -------------------------------
# GAME LOGIC
# -------------------------------

class SameGame:
    def __init__(self, rows=10, cols=10, num_colors=3):
        self.rows = rows
        self.cols = cols
        self.num_colors = num_colors
        self.grid = []
        self.score = 0
        self.selected_region = None   # ✅ selection state
        self.new_board()

    def new_board(self):
        self.grid = [
            [random.randrange(self.num_colors) for _ in range(self.cols)]
            for _ in range(self.rows)
        ]
        self.score = 0
        self.selected_region = None

    def in_bounds(self, r, c):
        return 0 <= r < self.rows and 0 <= c < self.cols

    def find_region(self, r, c):
        if not self.in_bounds(r, c):
            return []
        color = self.grid[r][c]
        if color is None:
            return []

        visited = set()
        stack = [(r, c)]
        region = []

        while stack:
            cr, cc = stack.pop()
            if (cr, cc) in visited:
                continue
            if not self.in_bounds(cr, cc):
                continue
            if self.grid[cr][cc] != color:
                continue

            visited.add((cr, cc))
            region.append((cr, cc))

            for dr, dc in [(1,0), (-1,0), (0,1), (0,-1)]:
                stack.append((cr + dr, cc + dc))

        return region

    def remove_region(self, region):
        n = len(region)
        if n >= 3:
            self.score += (n - 2) ** 2

        for r, c in region:
            self.grid[r][c] = None

        self.apply_gravity()
        self.shift_columns()
        self.selected_region = None

    def apply_gravity(self):
        for c in range(self.cols):
            col = [self.grid[r][c] for r in range(self.rows) if self.grid[r][c] is not None]
            col = [None] * (self.rows - len(col)) + col
            for r in range(self.rows):
                self.grid[r][c] = col[r]

    def shift_columns(self):
        new_cols = []
        for c in range(self.cols):
            if any(self.grid[r][c] is not None for r in range(self.rows)):
                new_cols.append([self.grid[r][c] for r in range(self.rows)])

        while len(new_cols) < self.cols:
            new_cols.append([None for _ in range(self.rows)])

        for c in range(self.cols):
            for r in range(self.rows):
                self.grid[r][c] = new_cols[c][r]

    def has_any_move(self):
        visited = set()
        for r in range(self.rows):
            for c in range(self.cols):
                if (r, c) in visited or self.grid[r][c] is None:
                    continue
                region = self.find_region(r, c)
                visited.update(region)
                if len(region) >= 2:
                    return True
        return False

    def check_game_over(self):
        if all(self.grid[r][c] is None for r in range(self.rows) for c in range(self.cols)):
            return True, f"You cleared the board! Final score: {self.score}"
        if not self.has_any_move():
            return True, f"No more moves. Final score: {self.score}"
        return False, ""


game = SameGame()

# -------------------------------
# FRONTEND
# -------------------------------
@app.route("/")
def home():
    return send_from_directory(".", "index.html")

@app.route("/api/get_board")
def get_board():
    over, msg = game.check_game_over()
    return jsonify({
        "grid": game.grid,
        "score": game.score,
        "selected": game.selected_region,
        "game_over": over,
        "message": msg
    })

@app.route("/api/new_board")
def new_board():
    game.new_board()
    return jsonify({"grid": game.grid, "score": game.score})

# -------------------------------
# USER CLICK (2-STEP CONFIRMATION)
# -------------------------------
@app.route("/api/click", methods=["POST"])
def click():
    data = request.get_json()
    r, c = data["r"], data["c"]
    region = game.find_region(r, c)

    # ❌ Single square → invalid
    if len(region) < 2:
        game.selected_region = None
        return jsonify({
            "grid": game.grid,
            "score": game.score,
            "invalid": True,
            "message": "Invalid move! Click a connected group of same color squares."
        })

    # ✅ First click → select only
    if game.selected_region != region:
        game.selected_region = region
        return jsonify({
            "grid": game.grid,
            "score": game.score,
            "selected": region,
            "confirm": False
        })

    # ✅ Second click → remove
    game.remove_region(region)

    # CPU plays ONLY after confirmed removal
    r2, c2, _ = cpu_choose_move(game.grid)
    if r2 != -1:
        cpu_region = game.find_region(r2, c2)
        if len(cpu_region) >= 2:
            game.remove_region(cpu_region)

    over, msg = game.check_game_over()
    return jsonify({
        "grid": game.grid,
        "score": game.score,
        "confirm": True,
        "game_over": over,
        "message": msg
    })

# -------------------------------
# RUN SERVER
# -------------------------------
if __name__ == "__main__":
    app.run(debug=True)
