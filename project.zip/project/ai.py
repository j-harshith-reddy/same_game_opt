# ai.py
# Same Game AI using:
# Graph (DFS for regions)
# Merge Sort (for sorting regions)
# Greedy (choose larger region first)
# Divide & Conquer (recursive future evaluation)

from collections import deque


# --------------------------------------------------
# 1. GRAPH: Find all connected regions using DFS
# --------------------------------------------------
def get_all_regions(grid):
    rows = len(grid)
    cols = len(grid[0]) if rows else 0

    visited = set()
    regions = []

    for r in range(rows):
        for c in range(cols):

            if grid[r][c] is None or (r, c) in visited:
                continue

            color = grid[r][c]
            stack = [(r, c)]
            region = []

            while stack:
                cr, cc = stack.pop()

                if (cr, cc) in visited:
                    continue

                if not (0 <= cr < rows and 0 <= cc < cols):
                    continue

                if grid[cr][cc] != color:
                    continue

                visited.add((cr, cc))
                region.append((cr, cc))

                # 4-directional neighbors
                stack.append((cr + 1, cc))
                stack.append((cr - 1, cc))
                stack.append((cr, cc + 1))
                stack.append((cr, cc - 1))

            regions.append(region)

    return regions


# --------------------------------------------------
# 2. MERGE SORT (Only sorting used)
# --------------------------------------------------
def merge_sort(arr):
    if len(arr) <= 1:
        return arr

    mid = len(arr) // 2
    left = merge_sort(arr[:mid])
    right = merge_sort(arr[mid:])

    result = []
    i = j = 0

    while i < len(left) and j < len(right):
        if left[i][0] > right[j][0]:   # descending order
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1

    result.extend(left[i:])
    result.extend(right[j:])

    return result


# --------------------------------------------------
# 3. SIMULATE MOVE (Remove + Gravity + Shift)
# --------------------------------------------------
def simulate_move(grid, region):
    rows = len(grid)
    cols = len(grid[0])

    new_grid = [row[:] for row in grid]

    # Remove region
    for r, c in region:
        new_grid[r][c] = None

    # Apply gravity
    for c in range(cols):
        column = [new_grid[r][c] for r in range(rows) if new_grid[r][c] is not None]
        column = [None] * (rows - len(column)) + column

        for r in range(rows):
            new_grid[r][c] = column[r]

    # Shift columns left
    new_columns = []

    for c in range(cols):
        if any(new_grid[r][c] is not None for r in range(rows)):
            new_columns.append([new_grid[r][c] for r in range(rows)])

    while len(new_columns) < cols:
        new_columns.append([None] * rows)

    final_grid = [[None] * cols for _ in range(rows)]

    for c in range(cols):
        for r in range(rows):
            final_grid[r][c] = new_columns[c][r]

    return final_grid


# --------------------------------------------------
# 4. DIVIDE & CONQUER RECURSION
# --------------------------------------------------
def recursive_score(grid, depth):

    if depth == 0:
        return 0

    regions = get_all_regions(grid)
    region_sizes = [(len(reg), idx) for idx, reg in enumerate(regions) if len(reg) >= 2]

    if not region_sizes:
        return 0

    sorted_regions = merge_sort(region_sizes)

    best_score = 0

    for size, idx in sorted_regions:
        region = regions[idx]

        # Greedy immediate score
        immediate = (size - 2) ** 2

        new_grid = simulate_move(grid, region)

        future = recursive_score(new_grid, depth - 1)

        total = immediate + future

        if total > best_score:
            best_score = total

    return best_score


# --------------------------------------------------
# 5. MAIN CPU FUNCTION
# --------------------------------------------------
def cpu_choose_move(grid, depth=2):
  

    regions = get_all_regions(grid)

    region_sizes = [(len(reg), idx) for idx, reg in enumerate(regions) if len(reg) >= 2]

    if not region_sizes:
        return -1, -1, {}

    # Sort using Merge Sort
    sorted_regions = merge_sort(region_sizes)

    best_total = -1
    best_idx = None

    for size, idx in sorted_regions:

        region = regions[idx]

        # Greedy immediate score
        immediate = (size - 2) ** 2

        new_grid = simulate_move(grid, region)

        future = recursive_score(new_grid, depth - 1)

        total = immediate + future

        if total > best_total:
            best_total = total
            best_idx = idx

    chosen_cell = regions[best_idx][0]

    return chosen_cell[0], chosen_cell[1], {
        "strategy": "Greedy + Divide & Conquer",
        "depth_used": depth,
        "final_score_estimation": best_total
    }
